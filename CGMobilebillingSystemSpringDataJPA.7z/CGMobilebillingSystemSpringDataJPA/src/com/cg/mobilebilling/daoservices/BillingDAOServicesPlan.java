package com.cg.mobilebilling.daoservices;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
public interface BillingDAOServicesPlan extends JpaRepository<Plan, Integer>{
	
}