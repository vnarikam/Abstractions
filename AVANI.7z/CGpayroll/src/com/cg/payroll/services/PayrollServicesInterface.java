package com.cg.payroll.services;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptionhandling.AssociateDetailsNotFound;

public interface PayrollServicesInterface {

	int acceptAssociateDetails(String firstName, String lastName, String department, String designation, String pancard,
			String emailId, int yearlyInvestmentUnder80C, float basicSalary, float epf, float companyPf,
			int accountNumber, String bankName, String ifscCode);

	float calculateNetSalary(int associateId) throws AssociateDetailsNotFound;
	
	boolean updateAssociate(Associate associate) throws AssociateDetailsNotFound;
	
	boolean deleteAssociate(int associateId) throws AssociateDetailsNotFound;

	Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFound;
	Associate[] getAllAssociateDetails();

}