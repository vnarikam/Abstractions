package com.cg.payroll.services;
import com.cg.payroll.beans.*;
import com.cg.payroll.daoservices.*;
import com.cg.payroll.exceptionhandling.AssociateDetailsNotFound;
public class PayrollServicesImpl implements PayrollServicesInterface {
	//private PayrollDAOServicesImpl daoServices = new PayrollDAOServicesImpl();
	private PayrollDAOServicesInterface daoServices;
	public PayrollServicesImpl(){
		daoServices = new PayrollDAOServicesImpl();
	}

	@Override
	public int acceptAssociateDetails(String firstName, String lastName,String department, String designation,
			String pancard, String emailId, int yearlyInvestmentUnder80C,float basicSalary,float epf, 
			float companyPf,int accountNumber, String bankName, String ifscCode){
		//Associate associate = new Associate( yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode));
		//return daoServices.insertAssociate(associate);
		return daoServices.insertAssociate(new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf),new BankDetails(accountNumber, bankName, ifscCode)) );
}
	public boolean deleteAssociate(int associateId) throws AssociateDetailsNotFound{
		boolean a = daoServices.deleteAssociate(associateId);
		if (a==false)
			throw new AssociateDetailsNotFound("kalyan");
		return daoServices.deleteAssociate(associateId);
		}
	public boolean updateAssociate(Associate associate) throws AssociateDetailsNotFound{
		
		return daoServices.updateAssociate(associate);
		}
	@Override
	public float calculateNetSalary(int associateId) throws AssociateDetailsNotFound{
		Associate associate = this.getAssociateDetails(associateId);
			float taxable,tax=0;
			associate.getSalary().setPersonalAllowance(0.3f*associate.getSalary().getBasicSalary());
			associate.getSalary().setConveyenceAllowance(0.2f*associate.getSalary().getBasicSalary());
			associate.getSalary().setOtherAllowance( 0.1f*associate.getSalary().getBasicSalary()); 
			associate.getSalary().setHra(0.25f*associate.getSalary().getBasicSalary());
			associate.getSalary().setGratuity(0.05f*associate.getSalary().getBasicSalary());
			associate.getSalary().setGrossSalary(associate.getSalary().getBasicSalary()+associate.getSalary().getPersonalAllowance()+associate.getSalary().getConveyenceAllowance()+associate.getSalary().getOtherAllowance()+associate.getSalary().getHra()+associate.getSalary().getCompanyPf());
			float annualSalary = associate.getSalary().getGrossSalary()*12;
			float unTaxable= associate.getYearlyInvestmentUnder80C() + associate.getSalary().getCompanyPf()+associate.getSalary().getEpf();
			if (unTaxable>150000){
				float taxable1=unTaxable-150000;
				taxable=annualSalary-150000+taxable1;
			}
			else	{
				taxable=annualSalary-unTaxable;
			}
			if (taxable>1000000){
				float taxable2=(taxable-1000000);
				tax=tax+(taxable2*0.3f);
				taxable=taxable-taxable2;
			}
			if(taxable>500000&&taxable<=1000000){
				float taxable2=(taxable-500000);
				tax=tax+(taxable2*0.2f);
				taxable=taxable-taxable2;		}

			if(taxable>250000&&taxable<=500000){
				float taxable2=(taxable-250000);
				tax=tax+(taxable2*0.1f);
				taxable=taxable-taxable2;	
			}
			associate.getSalary().setMonthlyTax(tax/12);
			associate.getSalary().setNetSalary(associate.getSalary().getGrossSalary()-associate.getSalary().getMonthlyTax()-associate.getSalary().getCompanyPf()-associate.getSalary().getEpf());
			return associate.getSalary().getNetSalary();
		}
	@Override
	public Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFound{
		Associate associate = daoServices.getAssociate(associateId);
		if (associate==null)
			throw new AssociateDetailsNotFound("ravi teja");
		return daoServices.getAssociate(associateId);
	}
	@Override
	public Associate[] getAllAssociateDetails(){
		return null;
	}
}


