package com.cg.banking.main;
import com.cg.banking.beans.*;

public class MainClass {
	public static void main(String[] args){
		
				Customer [] customer = new Customer[4];
				customer[0]=new Customer(125,898582,286874,"pavan","kalyan","siavapavankalyan12345@gmail.com","89858","21/10/1995",new Address(521105, "junction", "A.P", "India"),new Address(289654,"talwade","Maha","India"),new Account[3]);
				Account [] account = customer[0].getAccounts();
				account[0]= new Account(28682174,5200.32f,"Balance",new Transaction[3]);
				Transaction [] transactions = account[0].getTransactions();
				transactions[0]=new Transaction(124, 2582, "21/10/1995", "card", "talwade", "withdraw", 	"Sucess");
				
				System.out.println(customer[0].getAccounts()[0].getAccountBalance());
				
								
			
		
	}

}
