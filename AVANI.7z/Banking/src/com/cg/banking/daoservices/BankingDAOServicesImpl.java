package com.cg.banking.daoservices;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;

public class BankingDAOServicesImpl implements BankingDAOServices{
	private static Customer[] customerList = new Customer[10];
	private static int CUSTOMER_ID_COUNTER=111;
	private static int CUSTOMER_IDX_COUNTER=0;
	private static int ACCOUNT_ID_COUNTER=111;
	@Override
	public int insertCustomer(Customer customer) {
		customer.setCustomerId(CUSTOMER_ID_COUNTER++);	
		customerList[CUSTOMER_IDX_COUNTER++]=customer;
		return customer.getCustomerId();
	}

	@Override
	public long insertAccount(int customerId, Account account) {
		for(int i=0;i<customerList.length;i++)
			if(customerList[i]!=null && customerId==customerList[i].getCustomerId()){
				customerList[i].getAccounts()[customerList[i].getAccountIdxCounter()]=account;
				account.setAccountNumber(ACCOUNT_ID_COUNTER++);
				return account.getAccountNumber();
				}
				return 0;
	}

	@Override
	public boolean updateAccount(int customerId, Account account) {
		for(int i=0;i<customerList.length;i++)
			if(customerList[i]!=null && customerId==customerList[i].getCustomerId()){
				for(int j=0; j<customerList[i].getAccounts().length;j++)
					if(customerList[i].getAccounts()[j]!=null && customerList[i].getAccounts()[j].getAccountNumber()==accountNumber)
				customerList[i].getAccounts()[customerList[i].getAccountIdxCounter()]=account;	
			}
		return false;
	}

	@Override
	public int generatePin(int customerId, Account account) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Customer getCustomer(int customerId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customer[] getCustomers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Account[] getAccounts(int customerId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Transaction[] getTransactions(int customerId, long accountNo) {
		// TODO Auto-generated method stub
		return null;
	}

}
