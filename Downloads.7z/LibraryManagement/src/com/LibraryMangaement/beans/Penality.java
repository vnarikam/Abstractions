package com.LibraryMangaement.beans;

public class Penality {
		private int noOfDaysDelayed,penalityChargePerDay;
		private String penalityStatus;
		
		public Penality(int noOfDaysDelayed, int penalityChargePerDay,
				String penalityStatus) {
			super();
			this.noOfDaysDelayed = noOfDaysDelayed;
			this.penalityChargePerDay = penalityChargePerDay;
			this.penalityStatus = penalityStatus;
		}
		public int getNoOfDaysDelayed() {
			return noOfDaysDelayed;
		}
		public void setNoOfDaysDelayed(int noOfDaysDelayed) {
			this.noOfDaysDelayed = noOfDaysDelayed;
		}
		public int getPenalityChargePerDay() {
			return penalityChargePerDay;
		}
		public void setPenalityChargePerDay(int penalityChargePerDay) {
			this.penalityChargePerDay = penalityChargePerDay;
		}
		public String getPenalityStatus() {
			return penalityStatus;
		}
		public void setPenalityStatus(String penalityStatus) {
			this.penalityStatus = penalityStatus;
		}
		
}
