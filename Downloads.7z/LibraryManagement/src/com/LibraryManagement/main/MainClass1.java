package com.LibraryManagement.main;

import com.LibraryMangaement.beans.Address;
import com.LibraryMangaement.beans.Book;
import com.LibraryMangaement.beans.Issue;
import com.LibraryMangaement.beans.Penality;
import com.LibraryMangaement.beans.Return;
import com.LibraryMangaement.beans.User;

public class MainClass1 {

	
	public static void main(String[] args) {
		
		Address address = new Address("Hyderabad", "Telangana", "India", 8790532425l);
		Book book = new Book("Professional", "AA123", "Java", "yes", 15, 4, 11);
		Issue issue = new Issue("01-04-2018", "15-04-2018", "Pending", "AA123", 15);
		Penality penality = new Penality(10, 1, "paid");
		Return retur = new Return("25-04-2018", "returned", "AA123");
		User user = new User("Srivatsava", "N1234", 1456789123l);
		System.out.println(address.getMobileNo()+" "+book.getBookName()+" "+issue.getIssuedBookID());
	}

}
