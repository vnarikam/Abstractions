package com.cg.leavemanagemetystem.beans;

public class LeaveCancellation {
 private String reasonOfCancellation,cancellationStatus;

public LeaveCancellation(String reasonOfCancellation, String cancellationStatus) {
	super();
	this.reasonOfCancellation = reasonOfCancellation;
	this.cancellationStatus = cancellationStatus;
}

public String getReasonOfCancellation() {
	return reasonOfCancellation;
}

public void setReasonOfCancellation(String reasonOfCancellation) {
	this.reasonOfCancellation = reasonOfCancellation;
}

public String getCancellationStatus() {
	return cancellationStatus;
}

public void setCancellationStatus(String cancellationStatus) {
	this.cancellationStatus = cancellationStatus;
}
 	
}
