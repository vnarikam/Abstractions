package com.cg.leavemanagemetystem.beans;

public class Leaves {
	private int leavesDebited,leavesCredit,carryFwdLeaves,avaLeaves;

	public Leaves(int leavesDebited, int leavesCredit, int carryFwdLeaves,
			int avaLeaves) {
		super();
		this.leavesDebited = leavesDebited;
		this.leavesCredit = leavesCredit;
		this.carryFwdLeaves = carryFwdLeaves;
		this.avaLeaves = avaLeaves;
	}

	public int getLeavesDebited() {
		return leavesDebited;
	}

	public void setLeavesDebited(int leavesDebited) {
		this.leavesDebited = leavesDebited;
	}

	public int getLeavesCredit() {
		return leavesCredit;
	}

	public void setLeavesCredit(int leavesCredit) {
		this.leavesCredit = leavesCredit;
	}

	public int getCarryFwdLeaves() {
		return carryFwdLeaves;
	}

	public void setCarryFwdLeaves(int carryFwdLeaves) {
		this.carryFwdLeaves = carryFwdLeaves;
	}

	public int getAvaLeaves() {
		return avaLeaves;
	}

	public void setAvaLeaves(int avaLeaves) {
		this.avaLeaves = avaLeaves;
	}
	
}
