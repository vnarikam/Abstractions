
package com.cg.airReservation.main;

import com.cg.airReservation.beans.Passenger;

public class MainClass {
	public static void main(String[] str) {
		Passenger p=new Passenger("Vishal", "Sai", 88888888l);
		System.out.println(p.getFirstName());
	}
}
