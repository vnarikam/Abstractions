package com.cg.airReservation.beans;

public class Food {	
	private String FoodAplliedStatus,TypeOfFood;
	public Food() {
		// TODO Auto-generated constructor stub
	}
	public Food(String foodAplliedStatus, String typeOfFood) {
		super();
		FoodAplliedStatus = foodAplliedStatus;
		TypeOfFood = typeOfFood;
	}
	public String getFoodAplliedStatus() {
		return FoodAplliedStatus;
	}
	public void setFoodAplliedStatus(String foodAplliedStatus) {
		FoodAplliedStatus = foodAplliedStatus;
	}
	public String getTypeOfFood() {
		return TypeOfFood;
	}
	public void setTypeOfFood(String typeOfFood) {
		TypeOfFood = typeOfFood;
	}
}
