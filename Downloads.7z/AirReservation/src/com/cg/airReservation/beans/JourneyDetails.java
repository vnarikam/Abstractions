package com.cg.airReservation.beans;

public class JourneyDetails {
	private String From,To,Time,TimeOfClass;
	public JourneyDetails() {
		// TODO Auto-generated constructor stub
	}
	public JourneyDetails(String from, String to, String time, String timeOfClass) {
		super();
		From = from;
		To = to;
		Time = time;
		TimeOfClass = timeOfClass;
	}
	public String getFrom() {
		return From;
	}
	public void setFrom(String from) {
		From = from;
	}
	public String getTo() {
		return To;
	}
	public void setTo(String to) {
		To = to;
	}
	public String getTime() {
		return Time;
	}
	public void setTime(String time) {
		Time = time;
	}
	public String getTimeOfClass() {
		return TimeOfClass;
	}
	public void setTimeOfClass(String timeOfClass) {
		TimeOfClass = timeOfClass;
	}
	
}
