package com.cg.airReservation.beans;

public class Flight {
	private String BoardingPoint,EndingPoint,StartingTime,ReachingTime;
	public Flight() {
		// TODO Auto-generated constructor stub
	}
	public Flight(String boardingPoint, String endingPoint, String startingTime, String reachingTime) {
		super();
		BoardingPoint = boardingPoint;
		EndingPoint = endingPoint;
		StartingTime = startingTime;
		ReachingTime = reachingTime;
	}
	public String getBoardingPoint() {
		return BoardingPoint;
	}
	public void setBoardingPoint(String boardingPoint) {
		BoardingPoint = boardingPoint;
	}
	public String getEndingPoint() {
		return EndingPoint;
	}
	public void setEndingPoint(String endingPoint) {
		EndingPoint = endingPoint;
	}
	public String getStartingTime() {
		return StartingTime;
	}
	public void setStartingTime(String startingTime) {
		StartingTime = startingTime;
	}
	public String getReachingTime() {
		return ReachingTime;
	}
	public void setReachingTime(String reachingTime) {
		ReachingTime = reachingTime;
	}
}
