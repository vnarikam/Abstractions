package com.cg.airReservation.beans;

public class Cancellation {
	private String CancellationPolicy,LastDateForCancellation;
	private float CancellationCharges;
	public Cancellation() {
		// TODO Auto-generated constructor stub
	}
	public Cancellation(String cancellationPolicy, String lastDateForCancellation, float cancellationCharges) {
		super();
		CancellationPolicy = cancellationPolicy;
		LastDateForCancellation = lastDateForCancellation;
		CancellationCharges = cancellationCharges;
	}
	public String getCancellationPolicy() {
		return CancellationPolicy;
	}
	public void setCancellationPolicy(String cancellationPolicy) {
		CancellationPolicy = cancellationPolicy;
	}
	public String getLastDateForCancellation() {
		return LastDateForCancellation;
	}
	public void setLastDateForCancellation(String lastDateForCancellation) {
		LastDateForCancellation = lastDateForCancellation;
	}
	public float getCancellationCharges() {
		return CancellationCharges;
	}
	public void setCancellationCharges(float cancellationCharges) {
		CancellationCharges = cancellationCharges;
	}
	
}
