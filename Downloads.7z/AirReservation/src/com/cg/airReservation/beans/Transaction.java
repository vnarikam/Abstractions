package com.cg.airReservation.beans;

public class Transaction {
	private String TypeOfTransaction,TransactionStatus,TransactionDate;
	private float TransactionAmount;
	public Transaction() {
		// TODO Auto-generated constructor stub
	}
	public Transaction(String typeOfTransaction, String transactionStatus, String transactionDate,
			float transactionAmount) {
		super();
		TypeOfTransaction = typeOfTransaction;
		TransactionStatus = transactionStatus;
		TransactionDate = transactionDate;
		TransactionAmount = transactionAmount;
	}
	public String getTypeOfTransaction() {
		return TypeOfTransaction;
	}
	public void setTypeOfTransaction(String typeOfTransaction) {
		TypeOfTransaction = typeOfTransaction;
	}
	public String getTransactionStatus() {
		return TransactionStatus;
	}
	public void setTransactionStatus(String transactionStatus) {
		TransactionStatus = transactionStatus;
	}
	public String getTransactionDate() {
		return TransactionDate;
	}
	public void setTransactionDate(String transactionDate) {
		TransactionDate = transactionDate;
	}
	public float getTransactionAmount() {
		return TransactionAmount;
	}
	public void setTransactionAmount(float transactionAmount) {
		TransactionAmount = transactionAmount;
	}
}
