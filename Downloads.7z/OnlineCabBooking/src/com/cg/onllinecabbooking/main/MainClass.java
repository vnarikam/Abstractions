package com.cg.onllinecabbooking.main;

import com.cg.onllinecabbooking.beans.Customer;
import com.cg.onllinecabbooking.beans.Transaction;
import com.cg.onllinecabbooking.beans.TravellingDetails;

public class MainClass {

	public static void main(String[] args) {
		Customer customer = new Customer(89858162,"pavan","sivapavankalyan12345@gmail.com");
		TravellingDetails travellingdetails = new TravellingDetails("hyderabd","vijayawada","17/04/2018","19/04/2018","SUV",5,10000);
		Transaction transaction = new Transaction("cash","sucess","16/04/2018",659);
		System.out.println(transaction.getTransactionDate()+" "+customer.getMobileNo());		

	}

}
