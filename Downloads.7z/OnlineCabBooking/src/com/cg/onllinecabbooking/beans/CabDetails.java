package com.cg.onllinecabbooking.beans;

public class CabDetails {
	private int bookingID,OTP;
	private String vehicleNo,driverName;
	public CabDetails(int bookingID, int oTP, String vehicleNo, String driverName) {
		super();
		this.bookingID = bookingID;
		OTP = oTP;
		this.vehicleNo = vehicleNo;
		this.driverName = driverName;
	}
	public int getBookingID() {
		return bookingID;
	}
	public void setBookingID(int bookingID) {
		this.bookingID = bookingID;
	}
	public int getOTP() {
		return OTP;
	}
	public void setOTP(int oTP) {
		OTP = oTP;
	}
	public String getVehicleNo() {
		return vehicleNo;
	}
	public void setVehicleNo(String vehicleNo) {
		this.vehicleNo = vehicleNo;
	}
	public String getDriverName() {
		return driverName;
	}
	public void setDriverName(String driverName) {
		this.driverName = driverName;
	}
	
}
