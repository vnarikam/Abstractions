package com.cg.banking.services;

import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.BankingDAOServices;
import com.cg.banking.daoservices.BankingDAOServicesImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

public class BankingServicesImpl implements BankingServices{
public  BankingDAOServices bankingServices;
	

	public BankingServicesImpl() {
		bankingServices = new BankingDAOServicesImpl();
	}

	@Override
	public int acceptCustomerDetails(String firstName, String lastName, String customerEmailId, String panCard,
			String localAddressCity, String localAddressState, int localAddressPinCode, String homeAddressCity,
			String homeAddressState, int homeAddressPinCode) throws BankingServicesDownException {
		return bankingServices.insertCustomer(new Customer(firstName, lastName, customerEmailId, panCard, new Address(localAddressPinCode, localAddressCity, localAddressState), new Address(homeAddressPinCode, homeAddressCity, homeAddressState)));
	}

	@Override
	public long openAccount(int customerId, String accountType, float initBalance) throws InvalidAmountException,
			CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException {
		if(bankingServices.getCustomer(customerId)==null) 
			throw new CustomerNotFoundException("CustomerId not Found");
		
		if(accountType.equals("savings")||accountType.equals("current")||accountType.equals("salary")){
		if(initBalance<=0)
			throw new InvalidAmountException("please Enter amount other than 0 ");
		long a =  bankingServices.insertAccount(customerId, new Account(initBalance, accountType));
		bankingServices.insertTransaction(customerId, a, new Transaction(initBalance, "Deposit"));
		return a;
		}
		else
			  throw new InvalidAccountTypeException("Invalid Account Type");
		
	}

	@Override
	public float depositAmount(int customerId, long accountNo, float amount) throws CustomerNotFoundException,
			AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException {
		Account account = getAccountDetails(customerId, accountNo);
		if(bankingServices.getCustomer(customerId)==null) 
			throw new CustomerNotFoundException("CustomerId not Found");
		if(getAccountDetails(customerId, accountNo)==null)
			throw new AccountNotFoundException("Enter valid Account Number");
		if(getAccountDetails(customerId, accountNo).getStatus()=="blocked")
			throw new AccountBlockedException("Account is Blocked");
		if(amount<=0)
			throw new InvalidAmountException("please Enter amount other than 0 ");
		bankingServices.getAccount(customerId, accountNo).setAccountBalance(bankingServices.getAccount(customerId, accountNo).getAccountBalance()+amount);
		bankingServices.updateAccount(customerId, account);
		bankingServices.insertTransaction(customerId, accountNo, new Transaction(amount, "Deposit"));
		return bankingServices.getAccount(customerId, accountNo).getAccountBalance();
	}

	@Override
	public float withdrawAmount(int customerId, long accountNo, float amount, int pinNumber)
			throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		Account account = getAccountDetails(customerId, accountNo);
		if(getAccountDetails(customerId, accountNo).getStatus()=="blocked")
			throw new AccountBlockedException("Account is Blocked");
		if(bankingServices.getCustomer(customerId)==null) 
			throw new CustomerNotFoundException("CustomerId not Found");
		if(bankingServices.getAccount(customerId, accountNo)==null)
			throw new AccountNotFoundException("Enter valid Account Number");
		if(amount<=0||amount>getAccountDetails(customerId, accountNo).getAccountBalance()) 
			throw new InsufficientAmountException("Insufficient Amount in Your Account");
		if(pinNumber!=bankingServices.getAccount(customerId, accountNo).getPinNumber()) {
			account.setPinCounter(account.getPinCounter()+1);
			bankingServices.updateAccount(customerId, account);
			if(account.getPinCounter()>=2) {
				account.setStatus("blocked");
				bankingServices.updateAccount(customerId, account);
				throw new InvalidPinNumberException("Please Enter Correct PIN");
			}
			throw new InvalidPinNumberException("Please Enter Correct PIN");
			}
			else {
				account.setAccountBalance(bankingServices.getAccount(customerId, accountNo).getAccountBalance()-amount);
			bankingServices.updateAccount(customerId, account);
			bankingServices.insertTransaction(customerId, accountNo, new Transaction(amount, "Withdraw"));
			return bankingServices.getAccount(customerId, accountNo).getAccountBalance();
			}
	}

	@Override
	public boolean fundTransfer(int customerIdTo, long accountNoTo, int customerIdFrom, long accountNoFrom,
			float transferAmount, int pinNumber) throws InsufficientAmountException, CustomerNotFoundException,
			AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException, InvalidAmountException {
		getAccountDetails(customerIdTo, accountNoTo);
		getAccountDetails(customerIdFrom, accountNoFrom);
		if(withdrawAmount(customerIdFrom, accountNoFrom, transferAmount, pinNumber)!= -1)
		depositAmount(customerIdTo, accountNoTo, transferAmount);
		return true;
	}

	@Override
	public Customer getCustomerDetails(int customerId) throws CustomerNotFoundException, BankingServicesDownException {
		if(bankingServices.getCustomer(customerId)==null) 
			throw new CustomerNotFoundException("CustomerId not Found");
		return bankingServices.getCustomer(customerId);
	}

	@Override
	public Account getAccountDetails(int customerId, long accountNo) 
			throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException {
		if(bankingServices.getCustomer(customerId)==null) 
			throw new CustomerNotFoundException("CustomerId not Found");
		if(bankingServices.getAccount(customerId, accountNo)==null)
			throw new AccountNotFoundException("Enter valid Account Number");
		return bankingServices.getAccount(customerId, accountNo);
	}

	@Override
	public int generateNewPin(int customerId, long accountNo)
			throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException {
		if(bankingServices.getCustomer(customerId)==null) 
			throw new CustomerNotFoundException("CustomerId not Found");
		if(getAccountDetails(customerId, accountNo)==null)
			throw new AccountNotFoundException("Enter valid Account Number");
		bankingServices.generatePin(customerId, getAccountDetails(customerId, accountNo));
		return bankingServices.getAccount(customerId, accountNo).getPinNumber();
	}

	@Override
	public boolean changeAccountPin(int customerId, long accountNo, int oldPinNumber, int newPinNumber)
			throws CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException {
		if(bankingServices.getCustomer(customerId)==null) 
			throw new CustomerNotFoundException("CustomerId not Found");
		if(getAccountDetails(customerId, accountNo)==null)
			throw new AccountNotFoundException("Enter valid Account Number");
		if(oldPinNumber!=bankingServices.getAccount(customerId, accountNo).getPinNumber())
			throw new InvalidPinNumberException("please Enter Valid Pin");
		if (oldPinNumber==bankingServices.getAccount(customerId, accountNo).getPinNumber()){
			bankingServices.getAccount(customerId, accountNo).setPinNumber(newPinNumber);	
			return true;
		}
			return false;
	}

	@Override
	public List<Customer> getAllCustomerDetails() throws BankingServicesDownException {
		return bankingServices.getCustomers();
		
	}

	@Override
	public List<Account> getcustomerAllAccountDetails(int customerId)
			throws BankingServicesDownException, CustomerNotFoundException {
		if(bankingServices.getCustomer(customerId)==null) 
			throw new CustomerNotFoundException("CustomerId not Found");
		return bankingServices.getAccounts(customerId);
		
	}

	@Override
	public List<Transaction> getAccountAllTransaction(int customerId, long accountNo)
			throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException {
		if(bankingServices.getCustomer(customerId)==null) 
			throw new CustomerNotFoundException("CustomerId not Found");
		if(getAccountDetails(customerId, accountNo)==null)
			throw new AccountNotFoundException("Enter valid Account Number");
		return bankingServices.getTransactions(customerId, accountNo);
		
	}

	@Override
	public String accountStatus(int customerId, long accountNo) throws BankingServicesDownException,
			CustomerNotFoundException, AccountNotFoundException, AccountBlockedException {
		if(bankingServices.getCustomer(customerId)==null) 
			throw new CustomerNotFoundException("CustomerId not Found");
		if(getAccountDetails(customerId, accountNo)==null)
			throw new AccountNotFoundException("Enter valid Account Number");
		if(getAccountDetails(customerId, accountNo).getStatus()=="blocked")
			throw new AccountBlockedException("Account is Blocked");
		return getAccountDetails(customerId, accountNo).getStatus();
	}

	@Override
	public boolean closeAccount(int customerId, long accountNo)
			throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException {
		if(bankingServices.getCustomer(customerId)==null) 
			throw new CustomerNotFoundException("CustomerId not Found");
		if(getAccountDetails(customerId, accountNo)==null)
			throw new AccountNotFoundException("Enter valid Account Number");
		return bankingServices.deleteAccount(customerId, accountNo);
	}

	@Override
	public boolean removeCustomer(int customerId) throws CustomerNotFoundException, BankingServicesDownException {
		if(bankingServices.getCustomer(customerId)==null) 
			throw new CustomerNotFoundException("CustomerId not Found");
		return bankingServices.deleteCustomer(customerId);
	}

}
