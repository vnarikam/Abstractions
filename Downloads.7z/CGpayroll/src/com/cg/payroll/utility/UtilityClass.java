package com.cg.payroll.utility;

public class UtilityClass {
	public static int ASSOCIATE_ID_COUNTER=111;
}
