package com.cg.payroll.main;

import java.util.HashMap;
import java.util.List;
import java.util.Scanner;


import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.exceptionhandling.*;
import com.cg.payroll.services.*;
import com.cg.payroll.services.PayrollServicesImpl;
public class MainClass {

	public static void main(String[] args) {			
		int i=0;
		while(i!=7){
			System.out.println("Choose any option:\n1. For New Associate\n2. For Associate Details\n3. All Associate Details\n4. For Delete Associate\n5. For Update Associate");
			System.out.println("6. For Claculation of net Salary\n7. Exit");
			Scanner scr=new Scanner(System.in);
			i= scr.nextInt();
			try{
				PayrollServicesInterface payrollServicesImpl =new PayrollServicesImpl();
				switch (i) {
				case 1:
					System.out.println("Enter first name:\t");
					String firstName= scr.next();
					System.out.println("Enter last name:\t");
					String lastName= scr.next();
					System.out.println("Enter emailId:\t");
					String emailId= scr.next();
					System.out.println("Enter Department:\t");
					String department= scr.next();
					System.out.println("Enter Designation:\t");
					String designation= scr.next();
					System.out.println("Enter pancard:\t");
					String pancard= scr.next();
					System.out.println("Enter yearlyInvestmentUnder80C:\t");
					int yearlyInvestmentUnder80C= scr.nextInt();
					System.out.println("Enter basic salary:\t");
					float basicSalary= scr.nextFloat();
					System.out.println("Enter epf:\t");
					float epf= scr.nextFloat();
					System.out.println("Enter companyPf:\t");
					float companyPf= scr.nextFloat();
					System.out.println("Enter Account Number\t");
					int accountNumber=scr.nextInt();
					System.out.println("Enter Bank Name:\t");
					String bankName=scr.next();
					System.out.println("Enyer IFSC-CODE");
					String ifscCode=scr.next();
					System.out.println("your AssociateId is"+ payrollServicesImpl.acceptAssociateDetails(firstName, lastName, department, designation, pancard, emailId, yearlyInvestmentUnder80C, basicSalary, epf, companyPf, accountNumber, bankName, ifscCode));
					break;
				case 2:
					System.out.println("Enyer AssociateID:\t");
					int associateID=scr.nextInt();
					System.out.println(payrollServicesImpl.getAssociateDetails(associateID));
					break;
				case 3:
					List<Associate> associate=payrollServicesImpl.getAllAssociateDetails();
					for (Associate	a	: associate)
						System.out.println(a);
					break;
				case 4:
					System.out.println("Enyer AssociateID:\t");
					int associateID1=scr.nextInt();
					System.out.println(payrollServicesImpl.deleteAssociate(associateID1));
					break;
				case 5:
					System.out.println("Enyer AssociateID:\t");
					int associateID2=scr.nextInt();
					System.out.println("Enter first name:\t");
					String firstName1= scr.next();
					System.out.println("Enter last name:\t");
					String lastName1= scr.next();
					System.out.println("Enter emailId:\t");
					String emailId1= scr.next();
					System.out.println("Enter Department:\t");
					String department1= scr.next();
					System.out.println("Enter Designation:\t");
					String designation1= scr.next();
					System.out.println("Enter pancard:\t");
					String pancard1= scr.next();
					System.out.println("Enter yearlyInvestmentUnder80C:\t");
					int yearlyInvestmentUnder80C1= scr.nextInt();
					System.out.println("Enter basic salary:\t");
					float basicSalary1= scr.nextFloat();
					System.out.println("Enter epf:\t");
					float epf1= scr.nextFloat();
					System.out.println("Enter companyPf:\t");
					float companyPf1= scr.nextFloat();
					System.out.println("Enter Account Number\t");
					int accountNumber1=scr.nextInt();
					System.out.println("Enter Bank Name:\t");
					String bankName1=scr.next();
					System.out.println("Enyer IFSC-CODE");
					String ifscCode1=scr.next();
					System.out.println(payrollServicesImpl.updateAssociate(associateID2, firstName1, lastName1, department1, designation1, pancard1, emailId1, yearlyInvestmentUnder80C1, basicSalary1, epf1, companyPf1, accountNumber1, bankName1, ifscCode1));
					break;
				case 6:
					System.out.println("Enyer AssociateID:\t");
					int associateID3=scr.nextInt();
					System.out.println(payrollServicesImpl.calculateNetSalary(associateID3));
					break;
				case 7:
					break;
				}


			}
			catch(Exception e) {
				e.printStackTrace();


			}



		}
	}
}



