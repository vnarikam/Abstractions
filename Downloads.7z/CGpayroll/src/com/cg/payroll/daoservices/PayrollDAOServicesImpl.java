package com.cg.payroll.daoservices;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cg.payroll.beans.*;
import com.cg.payroll.utility.UtilityClass;
public class PayrollDAOServicesImpl implements PayrollDAOServicesInterface {

	//private static Associate[] associateList = new Associate[10];
	public static HashMap<Integer,Associate> associates = new HashMap<>();
	
	
	
	@Override
	public int insertAssociate(Associate associate){
		/*if(ASSOCIATE_IDX_COUNTER>0.7*associateList.length){
		  Associate temp[] = new Associate[10+associateList.length];
		  System.arraycopy(associateList, 0, temp, 0, associateList.length);
		  associateList=temp;
		
		}
		associate.setAssociateId(ASSOCIATE_ID_COUNTER++);
		associateList[ASSOCIATE_IDX_COUNTER++]=associate;
		return associate.getAssociateId();*/
		associate.setAssociateId(UtilityClass.ASSOCIATE_ID_COUNTER);
		associates.put(UtilityClass.ASSOCIATE_ID_COUNTER,associate);
		return associates.get(UtilityClass.ASSOCIATE_ID_COUNTER++).getAssociateId();
		
	}
	@Override
	public boolean updateAssociate(Associate associate){
		/*for(int i=0;i<associateList.length;i++)
			if(associateList[i]!=null &&associate.getAssociateId()==associateList[i].getAssociateId()){
				associateList[i]=associate;
				return true;		
			}
		return false;*/
		associates.put(associate.getAssociateId(),associate);
		return true;
	}
	@Override
	public boolean deleteAssociate(int associateId){
		/*for(int i=0;i<associateList.length;i++)
			if(associateList[i]!=null &&associateId ==associateList[i].getAssociateId()){
				associateList[i]=null;
				ASSOCIATE_IDX_COUNTER--;
					for(int j=0;j<associateList.length;j++)
						if(associateList[j]==null)
							for (int k = j+1; k < associateList.length; k++)
								if(associateList[k]!=null){
									associateList[j]=associateList[k];
									associateList[k]=null;
									break;
								}
				return true;		
			}	
		return false;
	}*/
		if(associates.remove(associateId)!=null)
		 return true;
		return false;
	}
		
	@Override
	public Associate getAssociate(int associateId){
	/*	for(int i=0;i<associateList.length;i++)
			if(associateList[i]!=null &&associateId ==associateList[i].getAssociateId())
				return associateList[i];
		return null;*/
		Associate b=associates.get(associateId);
		if(b==null) return null;
		return b;
		
	}
	@Override
	public List<Associate> getAllAssociatesDetails() {
		
			return new ArrayList(associates.values());
	}
	
}
