package com.cg.project.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.beans.UserBean;
@WebServlet("/Print")
public class Print extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ServletContext context;
	public void init(){
		context=getServletContext();
	}
	public void destroy() {}
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		UserBean userBean = new UserBean();
		userBean = (UserBean) context.getAttribute("userBean");
		userBean.setPhoneNo(request.getParameter("phoneNo"));
		userBean.setEmail(request.getParameter("email"));
		PrintWriter writer = response.getWriter();
		writer.println("<html>");
		writer.println("<head>");
		writer.println("<body>");
		writer.println("<div align=center>");
		writer.println("<table>");
		writer.println("<tr>");
		writer.println("<td><font color = 'green' font =10>FirstName</font></td><td>"+userBean.getFirstName()+"</td>");
		writer.println("</tr>");
		writer.println("<tr>");
		writer.println("<td><font color = 'green' font =10>LastName</font></td><td>"+userBean.getLastName()+"</td>");
		writer.println("</tr>");
		writer.println("<tr>");
		writer.println("<td><font color = 'green' font =10>City</font></td><td>"+userBean.getCity()+"</td>");
		writer.println("</tr>");
		writer.println("<tr>");
		writer.println("<td><font color = 'green' font =10>State</font></td><td>"+userBean.getState()+"</td>");
		writer.println("</tr>");
		writer.println("<tr>");
		writer.println("<td><font color = 'green' font =10> Phone</font></td><td>"+userBean.getPhoneNo()+"</td>");
		writer.println("<tr>");
		writer.println("<td><font color = 'green' font =10> Email</font></td><td>"+userBean.getEmail()+"</td>");
		writer.println("</tr>");
		writer.println("</table>");
		writer.println("</div>");
		writer.println("</body>");
		writer.println("</head>");
		writer.println("</html>");

	}

}
