package com.cg.project.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/Form2")
public class Form2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public void init(ServletConfig config) throws ServletException {}
	public void destroy() {}
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String firstName = request.getParameter("firstName");
		String lastName = request.getParameter("lastName");
		PrintWriter writer = response.getWriter();
		writer.println("<html>");
		writer.println("<head>");
		writer.println("<body>");
		writer.println("<div align=center>");
		writer.println("<form  action=Form3  method=post name =Form2>");
		writer.println("<table>");
		writer.println("<tr>");
		writer.println("<td><font color = 'green' font =10>FirstName</font></td><td>"+firstName+"</td>");
		writer.println("</tr>");
		writer.println("<tr>");
		writer.println("<td><font color = 'green' font =10>LastName</font></td><td>"+lastName+"</td>");
		writer.println("</tr>");
		writer.println("<tr>");
		writer.println("<td><font color = 'green' font =10>City</font></td>");
		writer.println("<td><input type=text name=city></td>");
		writer.println("</tr>");
		writer.println("<tr>");
		writer.println("<td><font color = 'green' font =10>State</font></td>");
		writer.println("<td><input type=text name=state></td>");
		writer.println("</tr>");
		writer.println("<tr>");
		writer.println("<td><input type=submit value=submit></td>");
		writer.println("</tr>");
		writer.println("</table>");
		writer.println("</form>");
		writer.println("</div>");
		writer.println("</body>");
		writer.println("</head>");
		writer.println("</html>");

	}

}
