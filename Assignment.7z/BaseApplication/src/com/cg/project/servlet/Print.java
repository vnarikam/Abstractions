package com.cg.project.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/Print")
public class Print extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public void init(ServletConfig config) throws ServletException {}
	public void destroy() {}
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String firstName = request.getParameter("firstName");
		String lastName = request.getParameter("lastName");
		String city = request.getParameter("city");
		String state = request.getParameter("state");
		String phone = request.getParameter("phone");
		String email = request.getParameter("email");
		PrintWriter writer = response.getWriter();
		writer.println("<html>");
		writer.println("<head>");
		writer.println("<body>");
		writer.println("<div align=center>");
		writer.println("<table>");
		writer.println("<tr>");
		writer.println("<td><font color = 'green' font =10>FirstName</font></td><td>"+firstName+"</td>");
		writer.println("</tr>");
		writer.println("<tr>");
		writer.println("<td><font color = 'green' font =10>LastName</font></td><td>"+lastName+"</td>");
		writer.println("</tr>");
		writer.println("<tr>");
		writer.println("<td><font color = 'green' font =10>City</font></td><td>"+city+"</td>");
		writer.println("</tr>");
		writer.println("<tr>");
		writer.println("<td><font color = 'green' font =10>State</font></td><td>"+state+"</td>");
		writer.println("</tr>");
		writer.println("<tr>");
		writer.println("<td><font color = 'green' font =10> Phone</font></td><td>"+phone+"</td>");
		writer.println("<tr>");
		writer.println("<td><font color = 'green' font =10> Email</font></td><td>"+email+"</td>");
		writer.println("</tr>");
		writer.println("</table>");
		writer.println("</div>");
		writer.println("</body>");
		writer.println("</head>");
		writer.println("</html>");

	}

}
