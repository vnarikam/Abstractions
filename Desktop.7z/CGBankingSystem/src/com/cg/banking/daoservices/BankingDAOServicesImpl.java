package com.cg.banking.daoservices;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import com.cg.banking.beans.*;
public class BankingDAOServicesImpl implements  BankingDAOServices{
	private static HashMap<Integer,Customer> customers = new HashMap<>();
	private static int CUSTOMER_ID_COUNTER=111;
	private static long  ACCOUNT_ID_COUNTER=22222;
	private static int TRANSACTION_ID_COUNTER=111;

	@Override
	public int insertCustomer(Customer customer) {
		customer.setCustomerId(CUSTOMER_ID_COUNTER);
		customers.put(CUSTOMER_ID_COUNTER, customer);
		return customers.get(CUSTOMER_ID_COUNTER++).getCustomerId();
	}

	@Override
	public long insertAccount(int customerId, Account account) {		
		getCustomer(customerId).getAccounts().put(ACCOUNT_ID_COUNTER, account);
		account.setAccountNo(ACCOUNT_ID_COUNTER);
		return customers.get(customerId).getAccounts().get(ACCOUNT_ID_COUNTER++).getAccountNo();

	}

	@Override
	public boolean updateAccount(int customerId, Account account) {
		if(customers.get(customerId).getAccounts().replace(account.getAccountNo(),account)!=null)
		return true;
		return false;
	}

	@Override
	public int generatePin(int customerId, Account account) {
		Random rand = new Random();
		account.setPinNumber(rand.nextInt(1000)+1); 
		updateAccount(customerId, account);
		return account.getPinNumber();
	}

	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		getAccount(customerId,accountNo).getTransactions().put(TRANSACTION_ID_COUNTER++, transaction);
		return true;
	}
	@Override
	public boolean deleteCustomer(int customerId) {
		if(customers.remove(customerId)!=null) return true;
		return false;
	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		if(customers.get(customerId).getAccounts().remove(accountNo)!=null) return true;
		return false;
	}

	@Override
	public Customer getCustomer(int customerId) {
		return customers.get(customerId);
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {
		return getCustomer(customerId).getAccounts().get(accountNo);
	}

	@Override
	public List<Customer> getCustomers() {
		return new ArrayList(customers.values());
	}

	@Override
	public List<Account> getAccounts(int customerId) {
		return new ArrayList(getCustomer(customerId).getAccounts().values());
	}

	@Override
	public List<Transaction> getTransactions(int customerId, long accountNo) {
		return new ArrayList(getAccount(customerId, accountNo).getTransactions().values());
	}

}
