package com.cg.banking.services;

import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.BankingDAOServices;
import com.cg.banking.daoservices.BankingDAOServicesImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

public class BankingServicesImpl implements BankingServices{
private BankingDAOServices bankingServices;
	

	public BankingServicesImpl() {
		bankingServices = new BankingDAOServicesImpl();
	}

	@Override
	public int acceptCustomerDetails(String firstName, String lastName, String customerEmailId, String panCard,
			String localAddressCity, String localAddressState, int localAddressPinCode, String homeAddressCity,
			String homeAddressState, int homeAddressPinCode) throws BankingServicesDownException {
		return bankingServices.insertCustomer(new Customer(firstName, lastName, customerEmailId, panCard, new Address(localAddressPinCode, localAddressCity, localAddressState), new Address(homeAddressPinCode, homeAddressCity, homeAddressState)));
	}

	@Override
	public long openAccount(int customerId, String accountType, float initBalance) throws InvalidAmountException,
			CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException {
		if(bankingServices.getCustomer(customerId)==null) 
			throw new CustomerNotFoundException("CustomerId not Found");
		if(accountType.equals("savings")||accountType.equals("current")||accountType.equals("salary")){
		if(initBalance==0)
			throw new InvalidAmountException("please Enter amount other than 0 ");
		return bankingServices.insertAccount(customerId, new Account(initBalance, accountType));
		}
		else
			  throw new InvalidAccountTypeException("Invalid Account Type");
		
	}

	@Override
	public float depositAmount(int customerId, long accountNo, float amount) throws CustomerNotFoundException,
			AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		Account account = bankingServices.getAccount(customerId, accountNo);
		if(bankingServices.getCustomer(customerId)==null) 
			throw new CustomerNotFoundException("babu chalu ekkuva cheyoddu nee customerid ledhu ikkada");
		if(getAccountDetails(customerId, accountNo)==null)
			throw new AccountNotFoundException("Enter valid Account Number");
		bankingServices.getAccount(customerId, accountNo).setAccountBalance(bankingServices.getAccount(customerId, accountNo).getAccountBalance()+amount);
		bankingServices.updateAccount(customerId, account);
		bankingServices.insertTransaction(customerId, accountNo, new Transaction(amount, "Deposit"));
		return bankingServices.getAccount(customerId, accountNo).getAccountBalance();
	}

	@Override
	public float withdrawAmount(int customerId, long accountNo, float amount, int pinNumber)
			throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		Account account = bankingServices.getAccount(customerId, accountNo);
		if(bankingServices.getCustomer(customerId)==null) 
			throw new CustomerNotFoundException("babu chalu ekkuva cheyoddu nee customerid ledhu ikkada");
		if(bankingServices.getAccount(customerId, accountNo)==null)
			throw new AccountNotFoundException("Enter valid Account Number");
		if(amount>getAccountDetails(customerId, accountNo).getAccountBalance()) 
			throw new InsufficientAmountException("Insufficient Amount in Your Account");
		if(pinNumber==account.getPinNumber()&&amount<=getAccountDetails(customerId, accountNo).getAccountBalance()){
		account.setAccountBalance(bankingServices.getAccount(customerId, accountNo).getAccountBalance()-amount);
		bankingServices.updateAccount(customerId, account);
		bankingServices.insertTransaction(customerId, accountNo, new Transaction(amount, "Withdraw"));
		return bankingServices.getAccount(customerId, accountNo).getAccountBalance();
		}
		if(pinNumber!=account.getPinNumber()){
			account.setPinCounter(account.getPinCounter()+1);
			return -1;
		}
		return -1;
	}

	@Override
	public boolean fundTransfer(int customerIdTo, long accountNoTo, int customerIdFrom, long accountNoFrom,
			float transferAmount, int pinNumber) throws InsufficientAmountException, CustomerNotFoundException,
			AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		if(withdrawAmount(customerIdFrom, accountNoFrom, transferAmount, pinNumber)!= -1)
		depositAmount(customerIdTo, accountNoTo, transferAmount);
		return true;
	}

	@Override
	public Customer getCustomerDetails(int customerId) throws CustomerNotFoundException, BankingServicesDownException {
		if(bankingServices.getCustomer(customerId)==null) 
			throw new CustomerNotFoundException("babu chalu ekkuva cheyoddu nee customerid ledhu ikkada");
		return bankingServices.getCustomer(customerId);
	}

	@Override
	public Account getAccountDetails(int customerId, long accountNo) 
			throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException {
		if(bankingServices.getCustomer(customerId)==null) 
			throw new CustomerNotFoundException("babu chalu ekkuva cheyoddu nee customerid ledhu ikkada");
		if(bankingServices.getAccount(customerId, accountNo)==null)
			throw new AccountNotFoundException("Enter valid Account Number");
		return bankingServices.getAccount(customerId, accountNo);
	}

	@Override
	public int generateNewPin(int customerId, long accountNo)
			throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException {
		if(bankingServices.getCustomer(customerId)==null) 
			throw new CustomerNotFoundException("babu chalu ekkuva cheyoddu nee customerid ledhu ikkada");
		if(getAccountDetails(customerId, accountNo)==null)
			throw new AccountNotFoundException("Enter valid Account Number");
		bankingServices.generatePin(customerId, getAccountDetails(customerId, accountNo));
		return bankingServices.getAccount(customerId, accountNo).getPinNumber();
	}

	@Override
	public boolean changeAccountPin(int customerId, long accountNo, int oldPinNumber, int newPinNumber)
			throws CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException {
		if(bankingServices.getCustomer(customerId)==null) 
			throw new CustomerNotFoundException("babu chalu ekkuva cheyoddu nee customerid ledhu ikkada");
		if(getAccountDetails(customerId, accountNo)==null)
			throw new AccountNotFoundException("Enter valid Account Number");
		if(oldPinNumber!=bankingServices.getAccount(customerId, accountNo).getPinNumber())
			throw new InvalidPinNumberException("please Enter Valid Pin");
		if (oldPinNumber==bankingServices.getAccount(customerId, accountNo).getPinNumber()){
			bankingServices.getAccount(customerId, accountNo).setPinNumber(newPinNumber);	
			return true;
		}
			return false;
	}

	@Override
	public List<Customer> getAllCustomerDetails() throws BankingServicesDownException {
		return bankingServices.getCustomers();
		
	}

	@Override
	public List<Account> getcustomerAllAccountDetails(int customerId)
			throws BankingServicesDownException, CustomerNotFoundException {
		if(bankingServices.getCustomer(customerId)==null) 
			throw new CustomerNotFoundException("babu chalu ekkuva cheyoddu nee customerid ledhu ikkada");
		return bankingServices.getAccounts(customerId);
		
	}

	@Override
	public List<Transaction> getAccountAllTransaction(int customerId, long accountNo)
			throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException {
		if(bankingServices.getCustomer(customerId)==null) 
			throw new CustomerNotFoundException("babu chalu ekkuva cheyoddu nee customerid ledhu ikkada");
		if(getAccountDetails(customerId, accountNo)==null)
			throw new AccountNotFoundException("Enter valid Account Number");
		return bankingServices.getTransactions(customerId, accountNo);
		
	}

	@Override
	public String accountStatus(int customerId, long accountNo) throws BankingServicesDownException,
			CustomerNotFoundException, AccountNotFoundException, AccountBlockedException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean closeAccount(int customerId, long accountNo)
			throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException {
		if(bankingServices.getCustomer(customerId)==null) 
			throw new CustomerNotFoundException("babu chalu ekkuva cheyoddu nee customerid ledhu ikkada");
		if(getAccountDetails(customerId, accountNo)==null)
			throw new AccountNotFoundException("Enter valid Account Number");
		return bankingServices.deleteAccount(customerId, accountNo);
	}

}
