package com.cg.payroll.daoservices;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cg.payroll.beans.*;
public class PayrollDAOServicesImpl implements PayrollDAOServicesInterface {

	//private static Associate[] associateList = new Associate[10];
	private static HashMap<Integer,Associate> associates = new HashMap<>();
	private static int ASSOCIATE_ID_COUNTER=111;
	private static int ASSOCIATE_IDX_COUNTER=0;
	
	
	@Override
	public int insertAssociate(Associate associate){
		/*if(ASSOCIATE_IDX_COUNTER>0.7*associateList.length){
		  Associate temp[] = new Associate[10+associateList.length];
		  System.arraycopy(associateList, 0, temp, 0, associateList.length);
		  associateList=temp;
		
		}
		associate.setAssociateId(ASSOCIATE_ID_COUNTER++);
		associateList[ASSOCIATE_IDX_COUNTER++]=associate;
		return associate.getAssociateId();*/
		associate.setAssociateId(ASSOCIATE_ID_COUNTER);
		associates.put(ASSOCIATE_ID_COUNTER,associate);
		return associates.get(ASSOCIATE_ID_COUNTER++).getAssociateId();
		
	}
	@Override
	public boolean updateAssociate(Associate associate){
		/*for(int i=0;i<associateList.length;i++)
			if(associateList[i]!=null &&associate.getAssociateId()==associateList[i].getAssociateId()){
				associateList[i]=associate;
				return true;		
			}
		return false;*/
		associates.put(ASSOCIATE_ID_COUNTER,associate);
		return true;
	}
	@Override
	public boolean deleteAssociate(int associateId){
		/*for(int i=0;i<associateList.length;i++)
			if(associateList[i]!=null &&associateId ==associateList[i].getAssociateId()){
				associateList[i]=null;
				ASSOCIATE_IDX_COUNTER--;
					for(int j=0;j<associateList.length;j++)
						if(associateList[j]==null)
							for (int k = j+1; k < associateList.length; k++)
								if(associateList[k]!=null){
									associateList[j]=associateList[k];
									associateList[k]=null;
									break;
								}
				return true;		
			}	
		return false;
	}*/
		Associate c=associates.remove(associateId);
		if(c==null) return false;
		return true;
	}
		
	@Override
	public Associate getAssociate(int associateId){
	/*	for(int i=0;i<associateList.length;i++)
			if(associateList[i]!=null &&associateId ==associateList[i].getAssociateId())
				return associateList[i];
		return null;*/
		Associate b=associates.get(associateId);
		if(b==null) return null;
		return b;
		
	}
	@Override
	public List<Associate> getAssociates(){
		return new ArrayList(associates.values());
	}
}
