package com.cg.project.servlet;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public void init(ServletConfig config) throws ServletException {}
	public void destroy() {}
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter writer = response.getWriter();
		String userName = request.getParameter("userName");
		String password = request.getParameter("password");
		writer.println("<html>");
		writer.println("<head>");
		writer.println("<body>");
		if(userName.equals("pavan")&&password.equals("kalyan"))
				writer.println("<p><font color = 'green' size=29> welcome </font></p>");
		else
			writer.println("<p><font color = 'red' size=29>Invalid userName or Password</font></p>");
		writer.println("</body>");
		writer.println("</head>");
		writer.println("</html>");
	}

}
