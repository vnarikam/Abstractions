/* package com.cg.payroll.main;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.daoservices.*;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.services.*;
public class MainClass3{
	PayrollServicesInterface payrollServices = new PayrollServicesImpl();

	public static void main(String[] args) {
		Associate associate =searchAssociate("pava");
		if(associate!=null)
		System.out.println(associate.getAssociateId());
		else
		System.out.println("not found");	
	}
public static Associate searchAssociate(String Name){
	Associate associates[] =new Associate[3];
	associates[0]=new Associate(199,123666,"pavan","kalyan","ece","analyst","BCKPT3639R","siva@gamil.com",new Salary(102525, 5200, 5000, 250, 5600, 230, 1000, 1000, 2500, 56233, 2555),new BankDetails(11111,"HDFC","HDFC50123"));
	associates[1]=new Associate(222,1238951,"surya","ece","depa","analyst","BPKTGG3444","surya@gamil.com",new Salary(22555,565,258,258,548,250,1000,1000,5000,52300,60236),new BankDetails(258963,"HDFC","HDFC5032"));
	for(Associate associate:associates){
		if( associate!=null&&associate.getFirstName()==Name&&associate.getYearlyInvestmentUnder80C()>15000&&associate.getSalary().getBasicSalary()>=35000 )
			return associate;
	}
	return null;
}
}*/
package com.cg.payroll.main;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.daoservices.*;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.services.*;

public class MainClass3 {
	public static void main(String[] args) {
		PayrollServicesImpl payrollServices = new PayrollServicesImpl();
		int empId=payrollServices.acceptAssociateDetails("pavan", "kalyan", "java", "analyst", "pof456ff", "sivapavan@gmail.com",100000 ,50000f, 1000f, 1000f, 5236, "HDFC", "HDFC546");
		payrollServices.calculateNetSalary(empId);
		System.out.println(payrollServices.getAssociateDetails(empId).toString());
		int empId2=payrollServices.acceptAssociateDetails("siva", "prasad", "java","analyst","ll558","prasad@gmail.com",139000 ,500000f, 1000f, 1000f, 5237, "SBI", "SBI25546");
		payrollServices.calculateNetSalary(empId2);
		System.out.println(payrollServices.getAssociateDetails(empId2).toString());
		int empId3=payrollServices.acceptAssociateDetails("pavan", "kalyan", "java", "analyst", "pof456ff", "sivapavan@gmail.com",100000 ,50000f, 1000f, 1000f, 5236, "HDFC", "HDFC546");
		payrollServices.calculateNetSalary(empId3);
		System.out.println(payrollServices.getAssociateDetails(empId3).toString());
		int empId4=payrollServices.acceptAssociateDetails("pavan", "kalyan", "java", "analyst", "pof456ff", "sivapavan@gmail.com",100000 ,50000f, 1000f, 1000f, 5236, "HDFC", "HDFC546");
		payrollServices.calculateNetSalary(empId4);
		System.out.println(payrollServices.getAssociateDetails(empId4).toString());
		int empId5=payrollServices.acceptAssociateDetails("pavan", "kalyan", "java", "analyst", "pof456ff", "sivapavan@gmail.com",100000 ,50000f, 1000f, 1000f, 5236, "HDFC", "HDFC546");
		payrollServices.calculateNetSalary(empId5);
		System.out.println(payrollServices.getAssociateDetails(empId5).toString());
		int empId6=payrollServices.acceptAssociateDetails("pavan", "kalyan", "java", "analyst", "pof456ff", "sivapavan@gmail.com",100000 ,50000f, 1000f, 1000f, 5236, "HDFC", "HDFC546");
		payrollServices.calculateNetSalary(empId6);
		System.out.println(payrollServices.getAssociateDetails(empId6).toString());
		int empId7=payrollServices.acceptAssociateDetails("pavan", "kalyan", "java", "analyst", "pof456ff", "sivapavan@gmail.com",100000 ,50000f, 1000f, 1000f, 5236, "HDFC", "HDFC546");
		payrollServices.calculateNetSalary(empId7);
		System.out.println(payrollServices.getAssociateDetails(empId7).toString());
		int empId8=payrollServices.acceptAssociateDetails("pavan", "kalyan", "java", "analyst", "pof456ff", "sivapavan@gmail.com",100000 ,50000f, 1000f, 1000f, 5236, "HDFC", "HDFC546");
		payrollServices.calculateNetSalary(empId8);
		System.out.println(payrollServices.getAssociateDetails(empId8).toString());
		int empId9=payrollServices.acceptAssociateDetails("pava", "kalyan", "java", "analyst", "pof456ff", "sivapavan@gmail.com",100000 ,50000f, 1000f, 1000f, 5236, "HDFC", "HDFC546");
		payrollServices.calculateNetSalary(empId9);
		System.out.println(payrollServices.getAssociateDetails(empId9).toString());
		int empId10=payrollServices.acceptAssociateDetails("pavan", "kalyan", "java", "analyst", "pof456ff", "sivapavan@gmail.com",100000 ,50000f, 1000f, 1000f, 5236, "HDFC", "HDFC546");
		payrollServices.calculateNetSalary(empId10);
		System.out.println(payrollServices.getAssociateDetails(empId10).toString());
		int empId11=payrollServices.acceptAssociateDetails("pavan", "kalyan", "java", "analyst", "pof456ff", "sivapavan@gmail.com",100000 ,50000f, 1000f, 1000f, 5236, "HDFC", "HDFC546");
		payrollServices.calculateNetSalary(empId11);
		System.out.println(payrollServices.getAssociateDetails(empId11).toString());
		Associate associate = new Associate();
		associate =payrollServices.getAssociateDetails(empId11);
		associate.setDesignation("parasad");
			System.out.println( payrollServices.updateAssociate(associate));
		payrollServices.deleteAssociate(empId9);
		System.out.println(payrollServices.getAssociateDetails(empId11).toString());
		System.out.println(payrollServices.getAssociateDetails(empId10).toString());
		System.out.println(payrollServices.getAssociateDetails(empId8).toString());
		System.out.println(payrollServices.getAssociateDetails(empId7).toString());
		System.out.println(payrollServices.getAssociateDetails(empId6).toString());
		System.out.println(payrollServices.getAssociateDetails(empId5).toString());
		System.out.println(payrollServices.getAssociateDetails(empId4).toString());
		System.out.println(payrollServices.getAssociateDetails(empId3).toString());
		System.out.println(payrollServices.getAssociateDetails(empId2).toString());
		System.out.println(payrollServices.getAssociateDetails(empId).toString());
		PayrollDAOServicesImpl payrollDAOServices = new PayrollDAOServicesImpl();
		System.out.println(payrollDAOServices.getASSOCIATE_IDX_COUNTER());
		
	}

} 


