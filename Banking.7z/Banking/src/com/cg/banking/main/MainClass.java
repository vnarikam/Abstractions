package com.cg.banking.main;
import com.cg.banking.beans.*;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass {
	public static void main(String[] args){
			BankingServicesImpl bankingServices = new BankingServicesImpl();
			int customerId=bankingServices.acceptCustomerDetails("pavan", "kalyan", "siva@gmail.com", "258kk85", "junction", "a.p", 521105, "talwade", "Maharastra", 585896);
			System.out.println(bankingServices.getCustomerDetails(customerId).getCustomerId());
			long accountNumber=bankingServices.openAccount(customerId, "savings", 500.00f);
			int customerId2=bankingServices.acceptCustomerDetails("pavan", "kalyan", "siva@gmail.com", "258kk85", "junction", "a.p", 521105, "talwade", "Maharastra", 585896);
			System.out.println(bankingServices.getCustomerDetails(customerId2).getCustomerId());
			long accountNumber2=bankingServices.openAccount(customerId2, "savings", 1000.00f);
			System.out.println(bankingServices.getCustomerDetails(customerId).getAccounts()[0].getAccountBalance());
			//bankingServices.updateAccount(customerId, new Account(20000f," currrent"));
			
			//System.out.println(bankingServices.getCustomerDetails(customerId).getAccounts()[0].getAccountBalance());	
			int a= bankingServices. getAccountDetails(customerId2, accountNumber2).getPin();
			//bankingServices.withdrawAmount(111, 111, 230f,a);					
			//System.out.println(bankingServices.getCustomerDetails(111).getAccounts()[0].getAccountBalance());
			//System.out.println(bankingServices. getAccountDetails(111, 111).getPin());
			bankingServices.fundTransfer(customerId, accountNumber, customerId2, accountNumber2, 200f, a);
			System.out.println(bankingServices.getCustomerDetails(customerId).getAccounts()[0].getAccountBalance());
			System.out.println(bankingServices.getCustomerDetails(customerId2).getAccounts()[0].getAccountBalance());
	}

}
