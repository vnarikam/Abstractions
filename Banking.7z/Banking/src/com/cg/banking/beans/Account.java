package com.cg.banking.beans;

public class Account {
	private long accountNumber;
	private float accountBalance;
	private String accountType;
    private Transaction [] transactions;
    private int transactionIdxCounter=0;
    private int pin,pinCounter=0;
	public Account(){}
	public Account(long accountNumber, float accountBalance, String accountType, Transaction[] transactions) {
		super();
		this.accountNumber = accountNumber;
		this.accountBalance = accountBalance;
		this.accountType = accountType;
		this.transactions = transactions;
	}
	
	public Account(float accountBalance, String accountType) {
		super();
		this.accountBalance = accountBalance;
		this.accountType = accountType;
	}
	public int getTransactionIdxCounter() {
		return transactionIdxCounter;
	}
	public void setTransactionIdCounter(int transactionIdxCounter) {
		this.transactionIdxCounter = transactionIdxCounter;
	}
	
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	public int getPinCounter() {
		return pinCounter;
	}
	public void setPinCounter(int pinCounter) {
		this.pinCounter = pinCounter;
	}
	public void setTransactionIdxCounter(int transactionIdxCounter) {
		this.transactionIdxCounter = transactionIdxCounter;
	}
	public long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}
	public float getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(float accountBalance) {
		this.accountBalance = accountBalance;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public Transaction[] getTransactions() {
		return transactions;
	}
	public void setTransactions(Transaction[] transactions) {
		this.transactions = transactions;
	}
		
}