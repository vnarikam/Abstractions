package com.cg.banking1.daoservices;

public class Banking1DAOServicesImpl {

}
