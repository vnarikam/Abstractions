package com.cg.banking.main;

import com.cg.banking.services.BankingServicesImpl;

public class MainClass {
	public static void main(String[] args) {
		try{
			BankingServicesImpl banking = new BankingServicesImpl();
			int a =banking.acceptCustomerDetails("pavan", "kalyan", "siva@gamil.com", "kk5788", "talwade", "Maharasra", 258963, "junction", "a.p", 521105);
			System.out.println(banking.getCustomerDetails(a).getHomeAddress());
			System.out.println(banking.openAccount(a, "savings", 500.23f));
			System.out.println(banking.openAccount(a, "current", 200f));
			//System.out.println(banking.depositAmount(a, 22222, 500.32f));
			int b=banking.getAccountDetails(a, 22222).getPinNumber();
			int c=banking.getAccountDetails(a, 22223).getPinNumber();
			//System.out.println(banking.withdrawAmount(a, 22222, 500, b));
			System.out.println(banking.fundTransfer(a, 22222, a, 22223, 100, c));
			System.out.println(banking.getAccountDetails(a, 22222).getAccountBalance());
			System.out.println(banking.getAccountDetails(a, 22223).getAccountBalance());
			System.out.println(banking.getAccountAllTransaction(a, 22222)[0]);
			System.out.println(banking.getcustomerAllAccountDetails(a)[0]);
			System.out.println(banking.depositAmount(a, 22222, 0));
			banking.changeAccountPin(a, 22222, b, 123);
			System.out.println(banking.getAccountDetails(a, 22222).getPinNumber());
			System.out.println(banking.withdrawAmount(a, 22222, 200, b));
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
}
