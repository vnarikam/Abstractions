package com.cg.banking.daoservices;

import java.util.Random;

import com.cg.banking.beans.*;
public class BankingDAOServicesImpl implements  BankingDAOServices{
	private static Customer[] customerList = new Customer[10];
	private static int CUSTOMER_ID_COUNTER=111;
	private static int CUSTOMER_IDX_COUNTER=0;
	private static long  ACCOUNT_ID_COUNTER=22222;
	private static int TRANSACTION_ID_COUNTER=111;

	@Override
	public int insertCustomer(Customer customer) {
		if (CUSTOMER_IDX_COUNTER>0.7*customerList.length){
			Customer temp[] = new Customer[10+customerList.length];
			System.arraycopy(customerList, 0, temp, 0, customerList.length);
			customerList=temp;
		}
		customer.setCustomerId(CUSTOMER_ID_COUNTER++);	
		customerList[CUSTOMER_IDX_COUNTER++]=customer;
		return customer.getCustomerId();
	}

	@Override
	public long insertAccount(int customerId, Account account) {		
		for(int i=0;i<customerList.length;i++)
			if(customerList[i]!=null && customerId==customerList[i].getCustomerId()){
				if (customerList[i].getAccountIdxCounter() == 0.3*customerList[i].getAccounts().length){
					Account temp[] = new Account[10+ customerList[i].getAccounts().length];
					System.arraycopy( customerList[i].getAccounts(), 0, temp, 0,  customerList[i].getAccounts().length);
					customerList[i].setAccounts(temp);
					}
				account.setAccountNo(ACCOUNT_ID_COUNTER++);
				customerList[i].getAccounts()[customerList[i].getAccountIdxCounter()]=account;
				customerList[i].setAccountIdxCounter(customerList[i].getAccountIdxCounter()+1);
				this.generatePin(customerId, account);
				return account.getAccountNo();
				}
		return 0;
	}

	@Override
	public boolean updateAccount(int customerId, Account account) {
		for(int i=0;i<customerList.length;i++)
			if(customerList[i]!=null && customerId==customerList[i].getCustomerId()){
				System.out.println("pavan");
				for(int j=0; j<customerList[i].getAccounts().length;j++)
					if(customerList[i].getAccounts()[j]!=null && customerList[i].getAccounts()[j].getAccountNo()==account.getAccountNo())
				customerList[i].getAccounts()[j]=account;	
				return true;
			}
		return false;
	}

	@Override
	public int generatePin(int customerId, Account account) {
		Random rand = new Random();
		account.setPinNumber(rand.nextInt(1000)+1);   
		return 0;
	}

	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		for(int i=0;i<customerList.length;i++){
			if(customerList[i]!=null && customerId==customerList[i].getCustomerId()){
				for(int j=0; j<customerList[i].getAccounts().length;j++){
					
					if( customerList[i].getAccounts()[j].getAccountNo()==accountNo){
								if(customerList[i].getAccounts()[j]!=null  && customerList[i].getAccounts()[j].getTransactionIdxCounter()==0.7*customerList[i].getAccounts().length){
										
										Transaction [] temp = new Transaction[10+ customerList[i].getAccounts()[j].getTransactions().length];
										System.arraycopy( customerList[i].getAccounts()[j].getTransactions(), 0, temp, 0,  customerList[i].getAccounts()[j].getTransactions().length);
										customerList[i].getAccounts()[j].setTransactions(temp);
								}
								transaction.setTransactionId(TRANSACTION_ID_COUNTER++);
							
								getAccount(customerId, accountNo).getTransactions()[customerList[i].getAccounts()[j].getTransactionIdxCounter()]=transaction;
							 customerList[i].getAccounts()[j].setTransactionIdxCounter(customerList[i].getAccounts()[j].getTransactionIdxCounter()+1);
				return true;
					}
			}
			}}
		return false;
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		for(int i=0;i<customerList.length;i++)
			if(customerList[i]!=null && customerId==customerList[i].getCustomerId()){
				customerList[i]=null;
				CUSTOMER_IDX_COUNTER--;
						for(int j=0;j<customerList.length;j++)
							if(customerList[j]==null)
								for (int k = j+1; k < customerList.length; k++)
									if(customerList[k]!=null){
										customerList[j]=customerList[k];
										customerList[k]=null;
										break;
									}
						return true;
			}
		return false;
	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		for(int i=0;i<customerList.length;i++)
			if(customerList[i]!=null && customerId==customerList[i].getCustomerId()){
				for(int j=0; j<customerList[i].getAccounts().length;j++)
					if(customerList[i].getAccounts()[j]!=null  &&  customerList[i].getAccounts()[j].getAccountNo()==accountNo){
						 customerList[i].getAccounts()[j]=null;
						customerList[i].setAccountIdxCounter(customerList[i].getAccountIdxCounter()-1);
						for(int k=0;k<customerList.length;k++)
							for(int l=0;l<customerList[k].getAccounts().length;l++)
							if(customerList[k].getAccounts()[l]==null)
								for(int p =l+1;p<customerList[k].getAccounts().length;p++)
									if(customerList[k].getAccounts()[p]!=null){
										customerList[k].getAccounts()[l]=customerList[k].getAccounts()[p];
										customerList[k].getAccounts()[p]=null;
										break;
									}
						}				
				}
		return false;
	}

	@Override
	public Customer getCustomer(int customerId) {
		for(int i=0;i<customerList.length;i++)
			if(customerList[i]!=null && customerList[i].getCustomerId()==customerId)
		return customerList[i];
		return null;
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {
		for(int i=0;i<customerList.length;i++)
			if(customerList[i]!=null && customerList[i].getCustomerId()==customerId)
				for(int j=0;j<customerList[i].getAccounts().length;j++)
					if(customerList[i].getAccounts()[j]!=null && customerList[i].getAccounts()[j].getAccountNo()==accountNo)
						return customerList[i].getAccounts()[j];
		return null;
	}

	@Override
	public Customer[] getCustomers() {
		return customerList;
	}

	@Override
	public Account[] getAccounts(int customerId) {
		for(int i=0;i<customerList.length;i++)
			if(customerList[i]!=null && customerList[i].getCustomerId()==customerId)
				return customerList[i].getAccounts();
		return null;
	}

	@Override
	public Transaction[] getTransactions(int customerId, long accountNo) {
		return getAccount(customerId, accountNo).getTransactions();
	//	return null;
	}

}
