package com.cg.payroll.services;

import com.cg.payroll.beans.Associate;

public interface PayrollServicesInterface {

	int acceptAssociateDetails(String firstName, String lastName, String department, String designation, String pancard,
			String emailId, int yearlyInvestmentUnder80C, float basicSalary, float epf, float companyPf,
			int accountNumber, String bankName, String ifscCode);

	float calculateNetSalary(int associateId);

	Associate getAssociateDetails(int associateId);

	Associate[] getAllAssociateDetails();

}