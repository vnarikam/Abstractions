package com.cg.payroll.daoservices;
import com.cg.payroll.beans.*;
public class PayrollDAOServicesImpl implements PayrollDAOServicesInterface {

	private static Associate[] associateList = new Associate[10];
	private static int ASSOCIATE_ID_COUNTER=111;
	private static int ASSOCIATE_IDX_COUNTER=0;

	@Override
	public int insertAssociate(Associate associate){
		associate.setAssociateId(ASSOCIATE_ID_COUNTER++);
		associateList[ASSOCIATE_IDX_COUNTER++]=associate;
		if(ASSOCIATE_IDX_COUNTER>=0.7*associateList.length){
		  Associate temp[] = new Associate[10+associateList.length];
		  System.arraycopy(associateList, 0, temp, 0, associateList.length);
		  associateList=temp;
		return associate.getAssociateId();
		}
		return 0;
	}
	@Override
	public boolean updateAssociate(Associate associate){
		for(int i=0;i<associateList.length;i++)
			if(associateList[i]!=null &&associate.getAssociateId()==associateList[i].getAssociateId()){
				associateList[i]=associate;
				return true;		
			}
		return false;
	}
	@Override
	public boolean deleteAssociate(int associateId){
		for(int i=0;i<associateList.length;i++)
			if(associateList[i]!=null &&associateId ==associateList[i].getAssociateId()){
				associateList[i]=null;
				ASSOCIATE_IDX_COUNTER--;
					for(int j=0;j<associateList.length;j++)
						if(associateList[j]==null)
							for (int k = j+1; k < associateList.length; k++)
								if(associateList[k]!=null){
									associateList[j]=associateList[k];
									associateList[k]=null;
									break;
								}
				return true;		
			}	
		return false;
	}
	@Override
	public Associate getAssociate(int associateId){
		for(int i=0;i<associateList.length;i++)
			if(associateList[i]!=null &&associateId ==associateList[i].getAssociateId())
				return associateList[i];
		return null;
	}
	@Override
	public Associate[] getAssociates(){
		return associateList;
	}
}
