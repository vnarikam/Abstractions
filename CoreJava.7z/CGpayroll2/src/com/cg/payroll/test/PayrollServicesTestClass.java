package com.cg.payroll.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;


import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.exceptionhandling.AssociateDetailsNotFound;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.services.PayrollServicesInterface;
import com.cg.payroll.utility.UtilityClass;

public class PayrollServicesTestClass {
	private static PayrollServicesImpl  payrollServices;
	@BeforeClass
	public static void setUpTestEnv(){
		payrollServices= new  PayrollServicesImpl();
	}
	@Before
	public void setUpMockData(){
		Associate associate1 = new Associate(UtilityClass.ASSOCIATE_ID_COUNTER++,15000, "pavan", "kalyan", "java", "S.E", "ap12358io", "siva@gmail.com", new Salary(200000f, 500f, 500f),new BankDetails(22222, "hdfc", "ggg78hjhj"));
		Associate associate2 = new Associate(UtilityClass.ASSOCIATE_ID_COUNTER++,15000, "venkata", "siva", "java", "S.E", "ap12358io", "siva@gmail.com", new Salary(200000f, 500f, 500f),new BankDetails(22222, "hdfc", "ggg78hjhj"));
		PayrollDAOServicesImpl.associates.put(associate1.getAssociateId(), associate1);
		PayrollDAOServicesImpl.associates.put(associate2.getAssociateId(), associate2);
		
	}
	@Test(expected = AssociateDetailsNotFound.class)
	public void testForInValidId() throws AssociateDetailsNotFound{
		payrollServices.getAssociateDetails(119);
	}
	@Test
	public void testForValidId() throws AssociateDetailsNotFound{
		assertEquals( new Associate(112,15000, "venkata", "siva", "java", "S.E", "ap12358io", "siva@gmail.com", new Salary(200000f, 500f, 500f),new BankDetails(22222, "hdfc", "ggg78hjhj")),payrollServices.getAssociateDetails(112));
		}
	
	@Test
	public void testForAcceptAssociateDetailsForValidData() {
		assertEquals(113,payrollServices.acceptAssociateDetails(	"pp", "kk", "java", "s.e", "121ddd121", "siva@gmail.com", 12345, 456987f, 500f, 500f, 456898, "hdfc456", "vsadh5465"));
	}
	@Test
	public void testForAcceptAssociateDetailsForinValidData() {
		assertNotEquals(148,payrollServices.acceptAssociateDetails(	"pp", "kk", "java", "s.e", "121ddd121", "siva@gmail.com", 12345, 456987f, 500f, 500f, 456898, "hdfc456", "vsadh5465"));
	}
	@Test
	public void testForDeleteAssociate() throws AssociateDetailsNotFound{
	assertTrue(payrollServices.deleteAssociate(111));
	}
	@Test(expected = AssociateDetailsNotFound.class)
	public void testForDeleteAssociateInvalidId() throws AssociateDetailsNotFound{
	assertFalse(payrollServices.deleteAssociate(118));
	}
	@Test
	public void testForUpdateDetailsValidId() throws AssociateDetailsNotFound{
		assertTrue(payrollServices.updateAssociate(111, "kal", "pk", "d.e", "s.e", "hdfhs454", "siva2gmail.com", 15000, 50000f, 1000f, 1000f, 12423,"shjk", "s212"));
	}
	@Test(expected = AssociateDetailsNotFound.class)
	public void testForUpdateDetailsInValidId() throws AssociateDetailsNotFound{
		
		payrollServices.updateAssociate(118, "kal", "pk", "d.e", "s.e", "hdfhs454", "siva2gmail.com", 15000, 50000f, 1000f, 1000f, 12423,"shjk", "s212");
	}
	@Test
	public void calculate()throws AssociateDetailsNotFound{
		assertNotEquals(0, payrollServices.calculateNetSalary(111),0);
	}
	
	
	@After
	public void endUpMockData(){
		payrollServices.getAllAssociateDetails().clear();
		UtilityClass.ASSOCIATE_ID_COUNTER=111;
	}
	@AfterClass
	public static void endUpTestEnv(){
		payrollServices = null ;
	}
}
