/*package com.cg.payroll.serilization;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
public class Serilization {
	public static void doserilization(File payroll) throws IOException{
		try(ObjectOutputStream dest = new ObjectOutputStream(new FileOutputStream(payroll))){
		dest.writeObject(PayrollDAOServicesImpl.associates);
			}
		}
	public static void doDeserilization(File payroll) throws FileNotFoundException, IOException, ClassNotFoundException {
		try(ObjectInputStream src = new ObjectInputStream(new FileInputStream(payroll))){
			PayrollDAOServicesImpl.associates= (HashMap<Integer, Associate>) (src.readObject());
		}
	}
}*/
