package com.cg.payroll.daoservices;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cg.payroll.beans.*;
//import com.cg.payroll.serilization.Serilization;
import com.cg.payroll.utility.UtilityClass;
public class PayrollDAOServicesImpl implements PayrollDAOServicesInterface {

	//private static Associate[] associateList = new Associate[10];
	public static HashMap<Integer,Associate> associates = new HashMap<>();
	
	
	
	@Override
	public int insertAssociate(Associate associate){
		associate.setAssociateId(UtilityClass.ASSOCIATE_ID_COUNTER);
		associates.put(UtilityClass.ASSOCIATE_ID_COUNTER,associate);
		return associates.get(UtilityClass.ASSOCIATE_ID_COUNTER++).getAssociateId();
		
	}
	@Override
	public boolean updateAssociate(Associate associate){
		/*for(int i=0;i<associateList.length;i++)
			if(associateList[i]!=null &&associate.getAssociateId()==associateList[i].getAssociateId()){
				associateList[i]=associate;
				return true;		
			}
		return false;*/
		associates.put(associate.getAssociateId(),associate);
		return true;
	}
	@Override
	public boolean deleteAssociate(int associateId){
		/*for(int i=0;i<associateList.length;i++)
			if(associateList[i]!=null &&associateId ==associateList[i].getAssociateId()){
				associateList[i]=null;
				ASSOCIATE_IDX_COUNTER--;
					for(int j=0;j<associateList.length;j++)
						if(associateList[j]==null)
							for (int k = j+1; k < associateList.length; k++)
								if(associateList[k]!=null){
									associateList[j]=associateList[k];
									associateList[k]=null;
									break;
								}
				return true;		
			}	
		return false;
	}*/
		if(associates.remove(associateId)!=null)
		 return true;
		return false;
	}
		
	@Override
	public Associate getAssociate(int associateId){
	/*	for(int i=0;i<associateList.length;i++)
			if(associateList[i]!=null &&associateId ==associateList[i].getAssociateId())
				return associateList[i];
		return null;*/
		Associate b=associates.get(associateId);
		if(b==null) return null;
		return b;
		
	}
	@Override
	public List<Associate> getAllAssociatesDetails() {
		
			return new ArrayList(associates.values());
	}
	public static void doserilization(File payroll) throws IOException{
		try(ObjectOutputStream dest = new ObjectOutputStream(new FileOutputStream(payroll))){
		dest.writeObject(PayrollDAOServicesImpl.associates);
			}
		}
	public static void doDeserilization(File payroll) throws FileNotFoundException, IOException, ClassNotFoundException {
		try(ObjectInputStream src = new ObjectInputStream(new FileInputStream(payroll))){
			PayrollDAOServicesImpl.associates= (HashMap<Integer, Associate>) (src.readObject());
			UtilityClass.ASSOCIATE_ID_COUNTER=UtilityClass.ASSOCIATE_ID_COUNTER+associates.size();
		}
	}
	
}
