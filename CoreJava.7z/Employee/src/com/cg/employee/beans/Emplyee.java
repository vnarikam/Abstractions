package com.cg.employee.beans;

public abstract class  Emplyee {
	private int employeeId;
	private float basicSalary,totalSalary;
	private String firstName,lastName;
	public Emplyee() {
		super();
	}
	public Emplyee(int employeeId, float basicSalary, String firstName, String lastName) {
		super();
		this.employeeId = employeeId;
		this.basicSalary = basicSalary;
		this.firstName = firstName;
		this.lastName = lastName;
	}
	public Emplyee(int employeeId,String firstName, String lastName) {
		super();
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public float getBasicSalary() {
		return basicSalary;
	}
	public void setBasicSalary(float basicSalary) {
		this.basicSalary = basicSalary;
	}
	public float getTotalSalary() {
		return totalSalary;
	}
	public void setTotalSalary(float totalSalary) {
		this.totalSalary = totalSalary;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public abstract void calculateSalary() ;
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", basicSalary=" + basicSalary + ", totalSalary=" + totalSalary
				+ ", firstName=" + firstName + ", lastName=" + lastName + "]";
	}
	
}
