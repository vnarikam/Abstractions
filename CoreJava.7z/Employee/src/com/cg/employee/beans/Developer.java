package com.cg.employee.beans;

public final class Developer extends PEmployee {
	private int noOfProjects,incentives;
	public Developer() {
		super();
	}

	public Developer(int employeeId, float basicSalary, String firstName, String lastName) {
		super(employeeId, basicSalary, firstName, lastName);	
	}
	public Developer(int employeeId, float basicSalary, String firstName, String lastName, int noOfProjects) {
		super(employeeId, basicSalary, firstName, lastName);	
		this.noOfProjects = noOfProjects;
	}

	public int getNoOfProjects() {
		return noOfProjects;
	}

	public void setNoOfProjects(int noOfProjects) {
		this.noOfProjects = noOfProjects;
	}

	public int getIncentives() {
		return incentives;
	}

	public void setIncentives(int incentives) {
		this.incentives = incentives;
	}
	public void calculateSalary() {
		super.calculateSalary();
		incentives=noOfProjects*1000;
		this.setTotalSalary(this.getTotalSalary()+incentives);
	}

	@Override
	public String toString() {
		return super.toString()+ "Developer [noOfProjects=" + noOfProjects + ", incentives=" + incentives + "]";
	}




}
