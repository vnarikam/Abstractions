package com.cg.employee.beans;

public class CEmployee  extends Emplyee{
		private float hrs,variablePay;

		public CEmployee() {
			super();
		}

		public CEmployee(int employeeId, float basicSalary, String firstName, String lastName) {
			super(employeeId, basicSalary, firstName, lastName);
		}
		public CEmployee(int employeeId,String firstName, String lastName,float hrs) {
			super(employeeId, firstName, lastName);
			this.hrs=hrs;
		}

		public float getHrs() {
			return hrs;
		}

		public void setHrs(float hrs) {
			this.hrs = hrs;
		}

		public float getVariablePay() {
			return variablePay;
		}
		public void setVariablePay(float variablePay) {
			this.variablePay=variablePay;
		}
		public void calculateSalary() {
			variablePay = hrs*1000;
			this.setTotalSalary(variablePay);
		}
		public void  CSign(){
			System.out.println("contract signed");
		}
		

		@Override
		public String toString() {
			return super.toString()+ "CEmployee [hrs=" + hrs + ", variablePay=" + variablePay + "TotalSalary="+this.getTotalSalary()+"]";
		}
		
	

}
