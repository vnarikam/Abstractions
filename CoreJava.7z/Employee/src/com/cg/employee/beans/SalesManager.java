package com.cg.employee.beans;

public final class SalesManager extends PEmployee {
	private  float salesAmount,commission;
	public SalesManager() {
		super();
	}

	public SalesManager(int employeeId, float basicSalary, String firstName, String lastName) {
		super(employeeId, basicSalary, firstName, lastName);
	}
	public SalesManager(int employeeId, float basicSalary, String firstName, String lastName,float salesAmount) {
		super(employeeId, basicSalary, firstName, lastName );
		this.salesAmount=salesAmount;
	}

	public float getSalesAmount() {
		return salesAmount;
	}

	public void setSalesAmount(float salesAmount) {
		this.salesAmount = salesAmount;
	}

	public float getCommission() {
		return commission;
	}

	public void setCommission(float commission) {
		this.commission = commission;
	}
	public void calculateSalary() {
		super.calculateSalary();
		commission=salesAmount*0.1f;
		this.setTotalSalary(this.getTotalSalary()+commission);
	}

	@Override
	public String toString() {
		return super.toString()+"SalesManager [salesAmount=" + salesAmount + ", commission=" + commission + "]";
	}
	
}
