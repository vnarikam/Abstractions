package com.cg.employee.main;
import com.cg.employee.beans.*;
public class MainClass {

	public static void main(String[] args) {
    /*   Emplyee emplyee = new Emplyee(12345,5000f,"pavan","kalyan");
		emplyee.calculateSalary();
		System.out.println(emplyee.toString());
		PEmployee pemployee = new PEmployee(123456,5000f,"anil","kumar");
		pemployee.calculateSalary();
		System.out.println(pemployee.toString());
		CEmployee cemployee = new CEmployee(123456,"pava","kalyan",20f,100f);
		cemployee.calculateSalary();
		System.out.println(cemployee.toString());
		Developer developer = new Developer(123,50000f,"paan","kalyan",10);
		developer.calculateSalary();
		System.out.println(developer.toString());
		SalesManager salesmanager = new SalesManager(126,5896f,"pk","n",2500f);
		salesmanager.calculateSalary();
		System.out.println(salesmanager.toString());*/
		
		Emplyee employee;
		employee = new CEmployee(123,"pj","kk",258f);		
		employee.calculateSalary();
		System.out.println(employee.toString());
		
		
		
		
	}
}
