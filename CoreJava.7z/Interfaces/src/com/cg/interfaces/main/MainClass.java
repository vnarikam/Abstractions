package com.cg.interfaces.main;
import com.cg.interfaces.beans.*;

public class MainClass {
	public static void main( String [] args){
	MathServices mathservice = new MathServicesImpl();
	System.out.println(mathservice.add(10,20));
}
}