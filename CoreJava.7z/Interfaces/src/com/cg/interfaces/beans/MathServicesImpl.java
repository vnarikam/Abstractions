package com.cg.interfaces.beans;

public class MathServicesImpl implements MathServices{

	@Override
	public int add(int a, int b) {
		return a+b;
	}

	@Override
	public int sub(int a, int b) {
		// TODO Auto-generated method stub
		return a+b;
	}

	@Override
	public int div(int a, int b) {
		// TODO Auto-generated method stub
		return a+b;
	}
}	
