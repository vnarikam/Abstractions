package com.cg.banking.utility;

public class UtilityClass {
	public static int CUSTOMER_ID_COUNTER=111;
	public static long  ACCOUNT_ID_COUNTER=22222;
	public static int TRANSACTION_ID_COUNTER=111;
}
