package com.cg.banking.test;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.BankingDAOServicesImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
import com.cg.banking.utility.UtilityClass;



public class Test {
	private static BankingServicesImpl bankingServices;
	@BeforeClass
	public static void setUpTestEnv(){
		bankingServices= new  BankingServicesImpl();
	}
	@Before
	public void setUpMockData() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, InvalidPinNumberException{
		Customer customer1=new Customer( "pavan", "kalyan", "siva@gmail.com", "sbj454", new Address(521105, "junction", "a.p"), new Address(4569877, "ghgh", "hggh") ); 
		customer1.setCustomerId(UtilityClass.CUSTOMER_ID_COUNTER++);
		//System.out.println(UtilityClass.CUSTOMER_ID_COUNTER);
		Account account1 = new Account(5000f,"savings");
		account1.setAccountNo(UtilityClass.ACCOUNT_ID_COUNTER++);
		account1.setStatus("Active");
		Transaction transaction1 = new Transaction(5000f, "deposit");
		transaction1.setTransactionId(UtilityClass.TRANSACTION_ID_COUNTER++);
		customer1.getAccounts().put(account1.getAccountNo(),account1);
		customer1.getAccounts().get(account1.getAccountNo()).getTransactions().put(transaction1.getTransactionId(), transaction1);
		BankingDAOServicesImpl.customers.put(customer1.getCustomerId(), customer1);
		System.out.println(customer1);

		//bankingServices.changeAccountPin(111, 22222, b, 789);
	}
	@org.junit.Test(expected=CustomerNotFoundException.class)
	public void testForInValidId() throws CustomerNotFoundException, BankingServicesDownException{
		bankingServices.getCustomerDetails(119);
	}
	@org.junit.Test
	public void testForValidId() throws CustomerNotFoundException, BankingServicesDownException{
		Customer customer1=new Customer( "pavan", "kalyan", "siva@gmail.com", "sbj454", new Address(521105, "junction", "a.p"), new Address(4569877, "ghgh", "hggh") ); 
		customer1.setCustomerId(111);
		Account account1 = new Account(5000f,"savings");
		account1.setAccountNo(22222);
		account1.setStatus("Active");
		Transaction transaction1 = new Transaction(5000f, "deposit");
		transaction1.setTransactionId(111);
		customer1.getAccounts().put(account1.getAccountNo(),account1);
		customer1.getAccounts().get(account1.getAccountNo()).getTransactions().put(transaction1.getTransactionId(), transaction1);
		System.out.println(bankingServices.getCustomerDetails(111));
		System.out.println(customer1);
		assertEquals(customer1, bankingServices.getCustomerDetails(111));

	}
	@org.junit.Test
	public void testForcusIdCreation() throws BankingServicesDownException{
		assertEquals(112, bankingServices.acceptCustomerDetails("siva", "prasad", "siva@gmail.com", "5as4s", "junction", "a.p", 456987, "shghj", "sdaklj", 545654));
	}
	@org.junit.Test
	public void testForcusIdCreationNegative() throws BankingServicesDownException{
		assertNotEquals(115, bankingServices.acceptCustomerDetails("siva", "prasad", "siva@gmail.com", "5as4s", "junction", "a.p", 456987, "shghj", "sdaklj", 545654));
	}
	@org.junit.Test
	public void testForAccIdCreation() throws  InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException{

		assertEquals(22223,bankingServices.openAccount(111, "savings", 5000f));
	}
	@org.junit.Test
	public void testForAccIdCreationNegative() throws  InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException{

		assertNotEquals(22224,bankingServices.openAccount(111, "savings", 5000f));
	}
	@org.junit.Test
	public void testForAccType() throws  InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException{

		assertEquals(22223,bankingServices.openAccount(111, "savings", 5000f));
	}

	@org.junit.Test(expected=InvalidAccountTypeException.class)
	public void testForAccTypeNegative() throws  InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException{
		bankingServices.openAccount(111, "vings", 5000f);
	}
	@org.junit.Test(expected=InvalidAmountException.class)
	public void testForInValidAmount() throws  InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException{

		assertEquals(22223,bankingServices.openAccount(111, "savings", -895));
	}
	//Deposit
	@org.junit.Test
	public void testForAmount() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		assertEquals(13000, bankingServices.depositAmount(111, 22222, 8000f), 0);
	}
	@org.junit.Test(expected=CustomerNotFoundException.class)
	public void testForInvalidIdDeposit() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		bankingServices.depositAmount(119, 22222, 8000f);
	}
	@org.junit.Test(expected=AccountNotFoundException.class)
	public void testForInvalidAccIdDeposit() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		bankingServices.depositAmount(111, 22228, 8000f);
	}
	@org.junit.Test(expected=InvalidAmountException.class)
	public void testForInvalidAmountDeposit() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		bankingServices.depositAmount(111, 22222, 0f);
	}
	@org.junit.Test(expected=AccountBlockedException.class)
	public void testForStatus() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		bankingServices.getAccountDetails(111, 22222).setStatus("blocked");
		assertEquals(13000, bankingServices.depositAmount(111, 22222, 8000f), 0);
	}
	//withdraw
	@org.junit.Test
	public void testForAmountWithdraw() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException{
		int b=bankingServices.generateNewPin(111, 22222);
		assertEquals(3000, bankingServices.withdrawAmount(111, 22222, 2000,b),0);
	}
	@org.junit.Test(expected=CustomerNotFoundException.class)
	public void testForInValidCusIdWithdraw() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException{
		int b=bankingServices.generateNewPin(111, 22222);
		bankingServices.withdrawAmount(118, 22222, 2000,b);
	}
	@org.junit.Test(expected=AccountNotFoundException.class)
	public void testForInValidAccIdWithdraw() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException{
		int b=bankingServices.generateNewPin(111, 22222);
		bankingServices.withdrawAmount(111, 22223, 2000,b);
	}
	@org.junit.Test(expected=InsufficientAmountException.class)
	public void testForInValidAmountWithdraw() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException{
		int b=bankingServices.generateNewPin(111, 22222);
		bankingServices.withdrawAmount(111, 22222, -10,b);
	}
	@org.junit.Test(expected=InsufficientAmountException.class)
	public void testForOverAmountWithdraw() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException{
		int b=bankingServices.generateNewPin(111, 22222);
		bankingServices.withdrawAmount(111, 22222, 895632,b);
	}
	@org.junit.Test(expected=InvalidPinNumberException.class)
	public void testForInValidPinWithdraw() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException{
		int b=bankingServices.generateNewPin(111, 22222);
		bankingServices.withdrawAmount(111, 22222, 1000,5464);
	}
	@org.junit.Test(expected=AccountBlockedException.class)
	public void testForStatusWithDraw() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException{
		bankingServices.getAccountDetails(111, 22222).setStatus("blocked");
		int b=bankingServices.generateNewPin(111, 22222);
		bankingServices.withdrawAmount(111, 22222, 8000f,b);
	}
	//FundTransfer
	@org.junit.Test
	public void testForFundTransferValid() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException, InvalidAccountTypeException{
		//bankingServices.getAccountDetails(111, 22222).setStatus("blocked");
		int b=bankingServices.generateNewPin(111, 22222);
		bankingServices.openAccount(111, "current", 2000f);
		assertTrue(bankingServices.fundTransfer(111, 22223, 111, 22222, 500, b));
	}
	@org.junit.Test(expected=CustomerNotFoundException.class)
	public void testForFundTransferinValid() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException, InvalidAccountTypeException{
		int b=bankingServices.generateNewPin(111, 22222);
		bankingServices.openAccount(111, "current", 2000f);
		assertTrue(bankingServices.fundTransfer(111, 22223, 121, 22222, 500, b));
	}
	@org.junit.Test(expected=CustomerNotFoundException.class)
	public void testForFundTransferinValid2() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException, InvalidAccountTypeException{
		//bankingServices.getAccountDetails(111, 22222).setStatus("blocked");
		int b=bankingServices.generateNewPin(111, 22222);
		bankingServices.openAccount(111, "current", 2000f);
		assertTrue(bankingServices.fundTransfer(121, 22223, 111, 22222, 500, b));
	}
	@org.junit.Test(expected=AccountNotFoundException.class)
	public void testForFundTransferinValid3() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException, InvalidAccountTypeException{
		//bankingServices.getAccountDetails(111, 22222).setStatus("blocked");
		int b=bankingServices.generateNewPin(111, 22222);
		bankingServices.openAccount(111, "current", 2000f);
		assertTrue(bankingServices.fundTransfer(111, 22224, 111, 22222, 500, b));
	}
	@org.junit.Test(expected=AccountNotFoundException.class)
	public void testForFundTransferinValid4() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException, InvalidAccountTypeException{
		//bankingServices.getAccountDetails(111, 22222).setStatus("blocked");
		int b=bankingServices.generateNewPin(111, 22222);
		bankingServices.openAccount(111, "current", 2000f);
		assertTrue(bankingServices.fundTransfer(111, 22223, 111, 22225, 500, b));
	}
	@org.junit.Test(expected=InsufficientAmountException.class)
	public void testForFundTransferinValid5() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException, InvalidAccountTypeException{
		//bankingServices.getAccountDetails(111, 22222).setStatus("blocked");
		int b=bankingServices.generateNewPin(111, 22222);
		bankingServices.openAccount(111, "current", 2000f);
		assertTrue(bankingServices.fundTransfer(111, 22223, 111, 22222, 50000, b));
	}
	@org.junit.Test(expected=InvalidPinNumberException.class)
	public void testForFundTransferinValid6() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException, InvalidAccountTypeException{
		//bankingServices.getAccountDetails(111, 22222).setStatus("blocked");
		int b=bankingServices.generateNewPin(111, 22222);
		bankingServices.openAccount(111, "current", 2000f);
		assertTrue(bankingServices.fundTransfer(111, 22223, 111, 22222, 50, 2565));
	}
	@org.junit.Test(expected=AccountBlockedException.class)
	public void testForFundTransferinValid7() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException, InsufficientAmountException, InvalidPinNumberException, InvalidAccountTypeException{
		bankingServices.getAccountDetails(111, 22222).setStatus("blocked");
		int b=bankingServices.generateNewPin(111, 22222);
		bankingServices.openAccount(111, "current", 2000f);
		assertTrue(bankingServices.fundTransfer(111, 22223, 111, 22222, 50, b));
	}
	@org.junit.Test
	public void testForGetCustomerDetails() throws CustomerNotFoundException, BankingServicesDownException{
		Customer customer1=new Customer( "pavan", "kalyan", "siva@gmail.com", "sbj454", new Address(521105, "junction", "a.p"), new Address(4569877, "ghgh", "hggh") ); 
		customer1.setCustomerId(111);
		Account account1 = new Account(5000f,"savings");
		account1.setAccountNo(22222);
		account1.setStatus("Active");
		Transaction transaction1 = new Transaction(5000f, "deposit");
		transaction1.setTransactionId(111);
		customer1.getAccounts().put(account1.getAccountNo(),account1);
		customer1.getAccounts().get(account1.getAccountNo()).getTransactions().put(transaction1.getTransactionId(), transaction1);
		assertEquals(customer1, bankingServices.getCustomerDetails(111)); 
	}
	@org.junit.Test
	public void testForGetCustomerAllAccountDetails() throws BankingServicesDownException, CustomerNotFoundException{
	Customer customer1=new Customer( "pavan", "kalyan", "siva@gmail.com", "sbj454", new Address(521105, "junction", "a.p"), new Address(4569877, "ghgh", "hggh") ); 
	customer1.setCustomerId(111);
	Account account1 = new Account(5000f,"savings");
	account1.setAccountNo(22222);
	account1.setStatus("Active");
	Transaction transaction1 = new Transaction(5000f, "deposit");
	transaction1.setTransactionId(111);
	customer1.getAccounts().put(account1.getAccountNo(),account1);
	customer1.getAccounts().get(account1.getAccountNo()).getTransactions().put(transaction1.getTransactionId(), transaction1);
	ArrayList<Account> accountList = new ArrayList<>(customer1.getAccounts().values());
	assertEquals( accountList,bankingServices.getcustomerAllAccountDetails(111));
	}
	@After
	public void endUpMockData() throws BankingServicesDownException{
		BankingDAOServicesImpl.customers.clear();
		UtilityClass.CUSTOMER_ID_COUNTER=111;
		UtilityClass.ACCOUNT_ID_COUNTER=22222;
		UtilityClass.TRANSACTION_ID_COUNTER=111;
	}
	@AfterClass
	public static void endUpTestEnv(){
		bankingServices = null ;
	}
}
